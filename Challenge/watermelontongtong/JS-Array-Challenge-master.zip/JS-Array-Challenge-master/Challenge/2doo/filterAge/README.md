# 문제제목

## 설명

배열 원소의 age가 30이상 50미만인 사람만 있는 객체의 배열을 만드세요

## Expected Output 

[ { name: '일미', age: 35 }, { name: '이미', age: 45 } ]
