const A = [1, 2, 3, 4, 5];
const B = [3, 4, 5, 6, 7];
// write your codes

const answer = A.filter((n) => B.includes(n));
console.log(answer);
