# 문제제목

## 설명

홀수만 뽑아 배열로 만드세요

## Expected Output 

[5, 1, 3]
