const inputArray = [100, 10, 20, 40];

// write your codes

let answer = 0;

inputArray.forEach((n) => {
  answer += n;
});

console.log(answer);
