# 문제제목

## 설명

reduce 메소드를 사용해 최댓값의 값을 maxValue에, 해당 값의 index를 idx에 넣은 객체를 출력하세요

## Expected Output 

{ maxValue: 85, idx: 7 }.
