# 문제제목

## 설명

입력받은 객채배열의 nickname을 key, name을 value로 하는 객체를 출력하세요

## Expected Output

{ hong: '홍길동', '2li': '둘리', '1Cin': '오스트랄로피테쿠스' }
