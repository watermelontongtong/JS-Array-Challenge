# 문제제목

## 설명

reduce 메소드를 사용해서 배열의 모든 수의 합을 구하세요.

## Expected Output 

106
