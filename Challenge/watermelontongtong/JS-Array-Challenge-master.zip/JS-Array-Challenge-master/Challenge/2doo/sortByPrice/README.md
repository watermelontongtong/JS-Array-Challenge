# 문제제목

## 설명

배열안의 객체를 price를 기준으로 오름차순 정렬한 배열을 출력하세요

## Expected Output 

[
  { name: '사과', price: 1000 },
  { name: '당근', price: 2000 },
  { name: '수박', price: 5000 },
  { name: '참외', price: 10000 }
]
