# 문제제목

## 설명

배열안의 객체를 price를 기준으로 오름차순 정렬한 배열을 출력하세요
만약 price가 같다면 quantity기준으로 오름차순 정렬하세요

## Expected Output 

[
  { name: '사과', price: 1000, quantity: 2 },
  { name: '오이', price: 2000, quantity: 49 },
  { name: '당근', price: 2000, quantity: 50 },
  { name: '참외', price: 5000, quantity: 10 },
  { name: '수박', price: 5000, quantity: 20 }
]
