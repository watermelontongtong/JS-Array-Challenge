# 문제제목

## 설명

every를 이용해서 모든 원소가 짝수인지 아닌지를 판별하세요

## Expected Output 

true