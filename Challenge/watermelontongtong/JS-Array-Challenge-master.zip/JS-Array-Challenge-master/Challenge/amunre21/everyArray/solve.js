const inputArray = [2, 4, 6, 8, 10];

// write your codes
const answer = inputArray.every(el => el%2===0);
console.log(answer)