# 문제제목

## 설명

두 배열의 교집합을 출력하세요!

## Expected Output 

[3, 4, 5]

## Test

```npm test```
- jest를 사용해서 test했습니다.   
- require를 사용하는 commonJS환경입니다.