const inputArray = [4, 2, 5, 1, 3];

// write your codes

exports.answer = function(arr){
  return arr.filter(el => el%2==1);
}

