// write your codes
function solution(inputArray) {
  return inputArray.includes('용가리');
}

exports.solution = solution;
