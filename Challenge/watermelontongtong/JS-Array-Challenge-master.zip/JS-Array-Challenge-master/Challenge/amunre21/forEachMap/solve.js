// write your codes
function solution(inputArray) {
  return inputArray.map(el => el+'%');
}

exports.solution = solution;
