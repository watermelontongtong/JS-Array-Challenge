// write your codes
function solution(inputArray) {
    const target = '용가리';
    return inputArray.includes(target);
}

exports.solution = solution;
