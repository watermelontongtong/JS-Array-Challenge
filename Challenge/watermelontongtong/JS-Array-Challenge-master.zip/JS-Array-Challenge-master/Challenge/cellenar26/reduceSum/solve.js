// write your codes
const inputArray = [10, 3, 20, 5, 8, 60];
function solution(inputArray) {
    return inputArray.reduce((acc, currrrrrr)=>{
        return acc+currrrrrr;
    });
}
exports.solution = solution;
