const inputArray = [100, 10, 20, 40];

// write your codes

const result = [];

inputArray.forEach( item => {
    result.push(`${item}%`);
})

console.log(result);