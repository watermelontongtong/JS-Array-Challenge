const inputArray = [100, 10, 20, 40];

// write your codes

const result = inputArray.map( item => `${item}%`);

console.log(result);