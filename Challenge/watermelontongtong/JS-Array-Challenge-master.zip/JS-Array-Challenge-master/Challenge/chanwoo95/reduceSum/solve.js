const inputArray = [10, 3, 20, 5, 8, 60];

// write your codes


const result = inputArray.reduce( (acc, n) => acc+n);

console.log(result);