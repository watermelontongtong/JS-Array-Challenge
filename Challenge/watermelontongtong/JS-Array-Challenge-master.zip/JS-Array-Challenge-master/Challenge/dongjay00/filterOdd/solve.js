const inputArray = [4, 2, 5, 1, 3];

// write your codes

const oddArray = inputArray.filter(num => num % 2);
console.log(oddArray);
