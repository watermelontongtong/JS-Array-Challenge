const inputArray = [100, 10, 20, 40];

// write your codes
const resultArray = inputArray.filter(res => res >= 40);
console.log(resultArray);
