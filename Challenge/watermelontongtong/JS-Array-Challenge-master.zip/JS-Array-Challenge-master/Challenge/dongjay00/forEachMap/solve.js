const inputArray = [100, 10, 20, 40];

// write your codes

let mapArray = [];
inputArray.forEach(res => {
  mapArray.push(res + "%");
});
console.log(mapArray);