const inputArray = [100, 10, 20, 40];

// write your codes
const mapArray = inputArray.map(res => res + '%');
console.log(mapArray);
