const inputArray = [4, 2, 5, 1, 3];

// write your codes

const result = inputArray.filter((item) => {
  return item % 2 !== 0;
});

console.log(result);
