const inputArray = [4, 2, 5, 1, 3];

// write your codes

const answer = inputArray.filter((element) => element % 2 === 1);
console.log(answer);
