const inputArray = [2, 4, 6, 8, 10];

// write your codes

console.log(inputArray.every((num) => num % 2 === 0));
