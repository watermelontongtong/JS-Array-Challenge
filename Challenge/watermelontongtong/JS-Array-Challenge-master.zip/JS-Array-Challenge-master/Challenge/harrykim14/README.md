# JS-Array-Challenge

## 자바스크립트 배열을 마스터 해보자!

Solved 2 problems: expDidOdd, filterAge (5/8) <br/>

Solved 14 problems: figureSkating, filterOdd, findWord, forEachFilter, forEachFilterIsNaN, forEachMap, forEachReduce, mapAddPercent, mapAppendOrder, reduceMaxValueNIndex, reduceNameNickname, reduceSum, sortByPrice, sortByPriceAndQuantity (5/9) <br/>

Solved 1 problem: filterIntersection (5/10) <br/>
