const inputArray = [4, 2, 5, 1, 3];

// write your codes
let oddArray = inputArray.filter(el => el % 2 !== 0)