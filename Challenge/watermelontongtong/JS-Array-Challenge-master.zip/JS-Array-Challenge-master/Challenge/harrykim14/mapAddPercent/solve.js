const inputArray = [100, 10, 20, 40];

// write your codes

let percentage = inputArray.map(el => el.toString() + "%")