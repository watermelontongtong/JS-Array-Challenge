# 문제제목

## 설명

배열의 값을 name 프로퍼티에 넣고 몇번째 원소인지를 order에 넣은 객체의 배열을 출력하세요

## Expected Output

[
{ name: '홍길동', order: 1 },
{ name: '둘리', order: 2 },
{ name: '루피', order: 3 }
]
