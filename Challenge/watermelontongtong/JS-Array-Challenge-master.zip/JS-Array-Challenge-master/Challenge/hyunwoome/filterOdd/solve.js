const inputArray = [4, 2, 5, 1, 3];

// write your codes

console.log(
  inputArray.filter((el) => {
    return el % 2 === 1;
  }),
);
