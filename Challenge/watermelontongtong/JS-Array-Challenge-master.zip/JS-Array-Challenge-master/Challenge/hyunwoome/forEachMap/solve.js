const inputArray = [100, 10, 20, 40];

// write your codes

let tmp = [];
inputArray.forEach((el) => {
  tmp.push(`${el}%`);
});
console.log(tmp);
