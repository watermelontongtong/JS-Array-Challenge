const inputArray = [10, 3, 20, 5, 8, 60];

// write your codes

console.log(
  inputArray.reduce((acc, cur) => {
    return acc + cur;
  }),
);
