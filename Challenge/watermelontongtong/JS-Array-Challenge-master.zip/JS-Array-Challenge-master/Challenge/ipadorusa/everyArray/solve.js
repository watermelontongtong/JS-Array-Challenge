const inputArray = [2, 4, 6, 8, 10];

// write your codes
const result = inputArray.every(n => n % 2 === 0);

console.log(result);
