// write your codes

const inputArray = ['고질라', '용가리 ', '울트라맨'];
function solution(inputArray) {
  return inputArray.includes('용가리');
}

solution(inputArray);
exports.solution = solution;
