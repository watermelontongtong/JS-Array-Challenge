// write your codes
function solution(inputArray) {
  return inputArray.filter(num => num >= 40)
}

exports.solution = solution;
