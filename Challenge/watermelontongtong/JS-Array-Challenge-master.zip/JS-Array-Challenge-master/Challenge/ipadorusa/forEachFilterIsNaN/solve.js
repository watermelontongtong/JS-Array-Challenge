// write your codes
function solution(inputArray) {
  return inputArray.filter(num => !isNaN(num))
}

exports.solution = solution;
