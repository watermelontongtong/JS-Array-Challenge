// write your codes
function solution(inputArray) {
  return inputArray.map(str => str + '%');
}

exports.solution = solution;
