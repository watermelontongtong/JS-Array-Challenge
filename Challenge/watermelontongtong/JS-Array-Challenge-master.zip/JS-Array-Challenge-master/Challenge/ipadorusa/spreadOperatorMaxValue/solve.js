// write your codes
function solution(inputArray) {
	return `max : ${Math.max(...inputArray)}, min : ${Math.min(...inputArray)}`;
}

exports.solution = solution;

// 'max : 10, min : 1'
