function solution(inputArray) {
  return inputArray.every((num) => num % 2 == 0);
}

exports.solution = solution;
