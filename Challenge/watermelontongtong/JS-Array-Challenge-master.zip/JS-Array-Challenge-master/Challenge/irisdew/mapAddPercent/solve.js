const inputArray = [100, 10, 20, 40];

// write your codes

const answer = inputArray.map((el) => el + "%");
console.log(answer);
