# 문제제목

## 설명

용가리라는 단어가 있으면 true 없으면 false를 출력

## Expected Output

true
