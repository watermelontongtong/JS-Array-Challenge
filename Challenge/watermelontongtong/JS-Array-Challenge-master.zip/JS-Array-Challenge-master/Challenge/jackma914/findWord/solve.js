const inputArray = ["잠", "자", "고", "싶", "다", "용가리"];

// write your codes

const result = inputArray.includes("용가리");
console.log(result);
