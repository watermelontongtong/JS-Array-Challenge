const inputArray = [100, 10, 20, 40];

// write your codes

// map 메소드를 사용해 배열 각각 숫자 뒤에 %를 붙인 문자열을 만드세요
const result = inputArray.map((el) => el + "%");
console.log(result);
