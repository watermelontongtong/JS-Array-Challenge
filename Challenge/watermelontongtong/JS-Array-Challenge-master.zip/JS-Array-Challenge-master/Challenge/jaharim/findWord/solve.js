const inputArray = ['잠', '자', '고', '싶', '다', '용가리'];

// write your codes

const result = inputArray.some((inputElement) => inputElement === "용가리");
console.log(result);