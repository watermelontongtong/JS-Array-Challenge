const inputArray = [100, 10, 20, 40];

// write your codes

const result = inputArray.filter((inputElement) => inputElement >= 40 );
console.log(result);
