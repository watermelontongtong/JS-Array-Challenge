const inputArray = [100, 10, 20, 40];

// write your codes

let acc = 0;
const result = inputArray.forEach((inputElement) => acc += inputElement );
console.log(acc);
