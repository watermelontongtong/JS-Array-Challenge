const inputArray = [100, 10, 20, 40];

// write your codes

const result = inputArray.map((inputElement) => `${inputElement}%`);
console.log(result);
