const inputArray = [10, 3, 20, 5, 8, 60];

// write your codes

const result = inputArray.reduce((prev, curr) => prev + curr, 0);
console.log(result);

