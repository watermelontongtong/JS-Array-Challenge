const inputArray = [2, 4, 6, 8, 10];

// write your codes
let answer = inputArray.every((val) => val % 2 === 0);
console.log(answer);
