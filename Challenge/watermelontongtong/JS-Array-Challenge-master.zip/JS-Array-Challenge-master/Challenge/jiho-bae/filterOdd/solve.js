const inputArray = [4, 2, 5, 1, 3];

// write your codes

const answer = inputArray.filter((val) => val % 2);
console.log(answer);
