const inputArray = [100, 10, 20, 40];

// write your codes
let answer = [];
inputArray.forEach((val) => answer.push(val + "%"));
console.log(answer);
