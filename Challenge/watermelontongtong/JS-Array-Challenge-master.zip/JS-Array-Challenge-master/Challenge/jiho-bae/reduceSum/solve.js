const inputArray = [10, 3, 20, 5, 8, 60];

// write your codes

const answer = inputArray.reduce((sum, val) => sum + val, 0);
console.log(answer);
