const inputArray = [];

// write your codes

