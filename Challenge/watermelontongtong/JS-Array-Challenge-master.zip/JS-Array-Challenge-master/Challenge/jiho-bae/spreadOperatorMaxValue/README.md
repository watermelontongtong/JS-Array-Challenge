# 문제제목

## 설명

Spread Operator를 이용해서 값의 최대, 최소값을 구하세요


## Expected Output 


max : 10, min : 1