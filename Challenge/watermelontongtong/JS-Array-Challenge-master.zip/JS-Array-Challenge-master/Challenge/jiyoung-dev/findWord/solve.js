// write your codes
function solution(inputArray) {
  return inputArray.includes('용가리');
}

exports.solution = solution;

// includes 메서드는 배열 내에 특정 요소가 포함되어 있는지 확인하여 true 또는 false를 반환한다. 